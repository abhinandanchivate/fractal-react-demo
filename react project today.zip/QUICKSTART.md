# 🚀 Quick Start Guide

## Get Running in 5 Minutes!

### Step 1: Install JSON Server (One-Time Setup)
```bash
npm install -g json-server
```

### Step 2: Navigate to Project Directory
```bash
cd employee-management
```

### Step 3: Start JSON Server
```bash
json-server --watch db.json --port 5000
```

**You should see:**
```
Resources
http://localhost:5000/employees
http://localhost:5000/teams
http://localhost:5000/departments
```

### Step 4: Open Application
Double-click `index.html` or open it in your browser

### Step 5: Verify Connection
Look for 🟢 **"API Connected"** in the top-right corner

---

## ✅ You're Ready!

Try these actions:

1. **Create** - Click "Add Employee"
2. **Read** - View all employees in the table
3. **Update** - Click "Edit" (✏️) on any employee
4. **Delete** - Click "Delete" (🗑️) on any employee
5. **Search** - Type in the search box
6. **Filter** - Use department dropdown
7. **Export** - Click "Export CSV"
8. **Analytics** - Click "Analytics" tab

---

## 🆘 Troubleshooting

**API Offline Error?**
- Make sure JSON Server is running in terminal
- Check http://localhost:5000/employees in browser
- Restart JSON Server if needed

**Port 5000 Already in Use?**
```bash
json-server --watch db.json --port 3001
```
Then change in `index.html`:
```javascript
const API_URL = 'http://localhost:3001';
```

---

## 📁 Project Structure
```
employee-management/
├── db.json              ← Database with sample data
├── index.html           ← Main application
├── package.json         ← NPM configuration
└── README.md            ← Full documentation
```

---

## 🎯 What's Included

✅ **10 Sample Employees** with complete profiles
✅ **5 Departments** with budgets
✅ **5 Teams** with members
✅ **Full CRUD Operations**
✅ **Search & Filter**
✅ **Analytics Dashboard**
✅ **Export to CSV**
✅ **Batch Operations**
✅ **Beautiful Ant Design UI**

---

## 🔗 API Endpoints

All available at `http://localhost:5000/`:

- `/employees` - Employee management
- `/teams` - Team information
- `/departments` - Department details
- `/attendance` - Attendance records
- `/leaves` - Leave requests
- `/projects` - Project tracking

---

## 💡 Pro Tips

1. **Keep Terminal Open** - JSON Server must stay running
2. **Check Console** - Press F12 for developer tools
3. **Backup db.json** - Make a copy before experimenting
4. **Test API Directly** - Visit http://localhost:5000/employees

---

## 🎨 Features to Try

### Advanced Search
Search works across:
- Name (first & last)
- Email
- Department
- Position
- Skills

### Multi-Select
1. Click checkboxes to select employees
2. Use "Select All" for current page
3. Click "Delete Selected" for batch delete

### Skills Management
- Add multiple skills when creating/editing
- Click X to remove skills
- Skills appear as tags in table

### Export Data
1. Apply filters (optional)
2. Click "Export CSV"
3. File downloads with timestamp

---

## ⚡ Quick Commands

```bash
# Start server
npm run server

# Start server with external access
npm run server:dev

# Install dependencies (if using package.json)
npm install
```

---

## 📊 Sample API Requests

**Get all employees:**
```
GET http://localhost:5000/employees
```

**Get single employee:**
```
GET http://localhost:5000/employees/1
```

**Filter by department:**
```
GET http://localhost:5000/employees?department=Engineering
```

**Search:**
```
GET http://localhost:5000/employees?q=john
```

**Sort by salary (descending):**
```
GET http://localhost:5000/employees?_sort=salary&_order=desc
```

---

## 🎉 Ready to Code!

You now have a fully functional employee management system!

**Next:** Check out the full README.md for advanced features and customization options.

**Happy Coding! 🚀**

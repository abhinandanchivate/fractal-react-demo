# 📡 API Testing Guide

## Testing JSON Server Endpoints

This guide shows how to test your JSON Server API using various methods.

---

## 🌐 Method 1: Browser Testing

Simply open these URLs in your browser:

```
http://localhost:5000/employees
http://localhost:5000/employees/1
http://localhost:5000/teams
http://localhost:5000/departments
http://localhost:5000/employees?department=Engineering
http://localhost:5000/employees?status=Active
http://localhost:5000/employees?_sort=salary&_order=desc
```

---

## 🔧 Method 2: Using cURL (Command Line)

### GET - Fetch All Employees
```bash
curl http://localhost:5000/employees
```

### GET - Fetch Single Employee
```bash
curl http://localhost:5000/employees/1
```

### GET - Filter by Department
```bash
curl http://localhost:5000/employees?department=Engineering
```

### GET - Search
```bash
curl http://localhost:5000/employees?q=john
```

### POST - Create New Employee
```bash
curl -X POST http://localhost:5000/employees \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Test",
    "lastName": "User",
    "email": "test@company.com",
    "phone": "+1-555-9999",
    "department": "Engineering",
    "position": "Test Engineer",
    "salary": 70000,
    "experience": 3,
    "joinDate": "2024-01-01",
    "status": "Active",
    "skills": ["Testing", "QA"],
    "education": "Bachelor in CS",
    "teamId": 1,
    "managerId": 1,
    "address": {
      "street": "123 Test St",
      "city": "Test City",
      "state": "TC",
      "zip": "12345"
    },
    "emergencyContact": {
      "name": "Emergency Contact",
      "relationship": "Friend",
      "phone": "+1-555-8888"
    },
    "avatar": "https://i.pravatar.cc/150?img=99"
  }'
```

### PUT - Update Employee (Full Replace)
```bash
curl -X PUT http://localhost:5000/employees/1 \
  -H "Content-Type: application/json" \
  -d '{
    "id": 1,
    "firstName": "John",
    "lastName": "Doe Updated",
    "email": "john.updated@company.com",
    "phone": "+1-555-0100",
    "department": "Engineering",
    "position": "Lead Developer",
    "salary": 105000,
    "experience": 9,
    "joinDate": "2022-01-15",
    "status": "Active",
    "skills": ["JavaScript", "React", "Node.js", "Python", "Docker"],
    "education": "Master in Computer Science",
    "teamId": 1,
    "managerId": null,
    "address": {
      "street": "123 Main St",
      "city": "San Francisco",
      "state": "CA",
      "zip": "94102"
    },
    "emergencyContact": {
      "name": "Jane Doe",
      "relationship": "Spouse",
      "phone": "+1-555-0199"
    },
    "avatar": "https://i.pravatar.cc/150?img=1"
  }'
```

### PATCH - Partial Update
```bash
curl -X PATCH http://localhost:5000/employees/1 \
  -H "Content-Type: application/json" \
  -d '{
    "salary": 110000,
    "position": "Senior Lead Developer"
  }'
```

### DELETE - Remove Employee
```bash
curl -X DELETE http://localhost:5000/employees/1
```

---

## 🔍 Method 3: Using JavaScript Fetch API

### GET Request
```javascript
fetch('http://localhost:5000/employees')
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error('Error:', error));
```

### POST Request
```javascript
fetch('http://localhost:5000/employees', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    firstName: 'Jane',
    lastName: 'Smith',
    email: 'jane@company.com',
    department: 'Marketing',
    status: 'Active'
  })
})
  .then(response => response.json())
  .then(data => console.log('Created:', data))
  .catch(error => console.error('Error:', error));
```

### PUT Request
```javascript
fetch('http://localhost:5000/employees/1', {
  method: 'PUT',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    id: 1,
    firstName: 'John',
    lastName: 'Doe',
    email: 'john.updated@company.com',
    department: 'Engineering',
    status: 'Active'
  })
})
  .then(response => response.json())
  .then(data => console.log('Updated:', data))
  .catch(error => console.error('Error:', error));
```

### DELETE Request
```javascript
fetch('http://localhost:5000/employees/1', {
  method: 'DELETE'
})
  .then(response => console.log('Deleted'))
  .catch(error => console.error('Error:', error));
```

---

## 🎯 Method 4: Using Postman

### Setup
1. Download Postman: https://www.postman.com/downloads/
2. Create a new collection: "Employee Management API"
3. Set base URL: `http://localhost:5000`

### Create Requests

#### GET All Employees
- Method: GET
- URL: `{{baseURL}}/employees`

#### GET Single Employee
- Method: GET
- URL: `{{baseURL}}/employees/1`

#### POST New Employee
- Method: POST
- URL: `{{baseURL}}/employees`
- Headers: `Content-Type: application/json`
- Body (raw JSON):
```json
{
  "firstName": "Test",
  "lastName": "User",
  "email": "test@company.com",
  "department": "Engineering",
  "status": "Active"
}
```

#### PUT Update Employee
- Method: PUT
- URL: `{{baseURL}}/employees/1`
- Headers: `Content-Type: application/json`
- Body: Full employee object

#### DELETE Employee
- Method: DELETE
- URL: `{{baseURL}}/employees/1`

---

## 📊 Advanced Query Examples

### Pagination
```bash
# First page (10 items)
curl "http://localhost:5000/employees?_page=1&_limit=10"

# Second page
curl "http://localhost:5000/employees?_page=2&_limit=10"
```

### Sorting
```bash
# Sort by salary (ascending)
curl "http://localhost:5000/employees?_sort=salary&_order=asc"

# Sort by multiple fields
curl "http://localhost:5000/employees?_sort=department,salary&_order=asc,desc"
```

### Filtering
```bash
# Exact match
curl "http://localhost:5000/employees?department=Engineering"

# Greater than or equal
curl "http://localhost:5000/employees?salary_gte=80000"

# Less than or equal
curl "http://localhost:5000/employees?experience_lte=5"

# Range
curl "http://localhost:5000/employees?salary_gte=70000&salary_lte=90000"

# Multiple filters
curl "http://localhost:5000/employees?department=Engineering&status=Active"
```

### Full-text Search
```bash
# Search across all fields
curl "http://localhost:5000/employees?q=developer"
```

### Relationships
```bash
# Get employee with team data
curl "http://localhost:5000/employees/1?_expand=team"

# Get team with all employees
curl "http://localhost:5000/teams/1?_embed=employees"
```

### Operators
```bash
# Not equal
curl "http://localhost:5000/employees?status_ne=Inactive"

# Like (contains)
curl "http://localhost:5000/employees?email_like=company.com"

# Greater than
curl "http://localhost:5000/employees?experience_gt=5"

# Less than
curl "http://localhost:5000/employees?salary_lt=100000"
```

---

## 🧪 Testing Scenarios

### Scenario 1: Complete CRUD Flow
```bash
# 1. CREATE
curl -X POST http://localhost:5000/employees \
  -H "Content-Type: application/json" \
  -d '{"firstName":"Test","lastName":"User","email":"test@test.com","department":"IT","status":"Active"}'

# Note the ID from response (e.g., 11)

# 2. READ
curl http://localhost:5000/employees/11

# 3. UPDATE
curl -X PATCH http://localhost:5000/employees/11 \
  -H "Content-Type: application/json" \
  -d '{"salary":75000}'

# 4. DELETE
curl -X DELETE http://localhost:5000/employees/11

# 5. VERIFY
curl http://localhost:5000/employees/11
# Should return 404
```

### Scenario 2: Search and Filter
```bash
# Find all Engineering employees
curl "http://localhost:5000/employees?department=Engineering"

# Find active employees earning over 80k
curl "http://localhost:5000/employees?status=Active&salary_gte=80000"

# Search for "developer"
curl "http://localhost:5000/employees?q=developer"
```

### Scenario 3: Complex Queries
```bash
# Get top 5 highest paid employees
curl "http://localhost:5000/employees?_sort=salary&_order=desc&_limit=5"

# Get employees with 5+ years experience in Engineering
curl "http://localhost:5000/employees?department=Engineering&experience_gte=5"

# Get all active employees sorted by name
curl "http://localhost:5000/employees?status=Active&_sort=firstName,lastName"
```

---

## 📈 Response Status Codes

- **200 OK** - Successful GET, PUT, PATCH
- **201 Created** - Successful POST
- **204 No Content** - Successful DELETE
- **404 Not Found** - Resource doesn't exist
- **400 Bad Request** - Invalid data
- **500 Internal Server Error** - Server error

---

## 💡 Tips

1. **Pretty Print JSON:**
   ```bash
   curl http://localhost:5000/employees/1 | json_pp
   # or
   curl http://localhost:5000/employees/1 | python -m json.tool
   ```

2. **Save Response to File:**
   ```bash
   curl http://localhost:5000/employees > employees.json
   ```

3. **Include Headers in Response:**
   ```bash
   curl -i http://localhost:5000/employees/1
   ```

4. **Verbose Output (Debug):**
   ```bash
   curl -v http://localhost:5000/employees/1
   ```

5. **Test in Browser Console:**
   - Open browser DevTools (F12)
   - Go to Console tab
   - Run fetch commands directly

---

## 🔒 Important Notes

1. **JSON Server is for Development Only**
   - Not suitable for production
   - No authentication
   - No advanced security features

2. **Data Persistence**
   - Changes persist in db.json
   - Restart server to reload from file
   - Keep backup of original db.json

3. **Port Availability**
   - Default port: 5000
   - Change with: `--port 3001`

4. **CORS**
   - Automatically handled by JSON Server
   - All origins allowed by default

---

## 🎯 Quick Reference

| Operation | Method | URL Pattern | Body Required |
|-----------|--------|-------------|---------------|
| List All | GET | `/employees` | No |
| Get One | GET | `/employees/:id` | No |
| Create | POST | `/employees` | Yes |
| Update All | PUT | `/employees/:id` | Yes |
| Update Partial | PATCH | `/employees/:id` | Yes |
| Delete | DELETE | `/employees/:id` | No |

---

## 📚 Additional Resources

- [JSON Server GitHub](https://github.com/typicode/json-server)
- [REST API Design Best Practices](https://restfulapi.net/)
- [HTTP Status Codes](https://httpstatuses.com/)
- [cURL Documentation](https://curl.se/docs/)
- [Postman Learning Center](https://learning.postman.com/)

---

**Happy Testing! 🚀**

# 🚀 Advanced Employee Management System with JSON Server

## Complete CRUD Application with Ant Design & Vanilla JavaScript

---

## 📋 Table of Contents
1. [Overview](#overview)
2. [Features](#features)
3. [Prerequisites](#prerequisites)
4. [Installation & Setup](#installation--setup)
5. [Running the Application](#running-the-application)
6. [API Endpoints](#api-endpoints)
7. [Application Features](#application-features)
8. [Tech Stack](#tech-stack)
9. [Troubleshooting](#troubleshooting)

---

## 🎯 Overview

This is a comprehensive Employee Management System featuring:
- **Full CRUD Operations** (Create, Read, Update, Delete)
- **Real JSON Server Backend** for REST API
- **Beautiful Ant Design UI** with modern styling
- **Advanced Features**: Search, Filter, Sort, Pagination, Batch Operations
- **Analytics Dashboard** with interactive charts
- **Multi-tab Interface** for Employees, Teams, Departments
- **Complex Data Relationships** (Teams, Departments, Projects, Attendance)

---

## ✨ Features

### Employee Management
- ✅ Create new employees with comprehensive details
- ✅ View employee list with avatars and key information
- ✅ Edit employee information
- ✅ Delete employees (single or batch)
- ✅ Real-time search across all fields
- ✅ Filter by department and status
- ✅ Sort by any column
- ✅ Pagination (10 items per page)
- ✅ Export to CSV
- ✅ Multi-select for batch operations

### Employee Details Include
- Personal Information (Name, Email, Phone)
- Job Information (Department, Position, Salary, Experience)
- Skills management (Add/Remove multiple skills)
- Address details
- Emergency contact information
- Team and Manager assignment
- Join date and status tracking
- Performance metrics

### Additional Modules
- 📊 **Analytics Dashboard** - Visual charts for insights
- 👥 **Teams Management** - View and manage teams
- 🏢 **Departments Management** - Department overview with budgets
- 📈 **Statistics** - Real-time stats in header

---

## 📦 Prerequisites

Before you begin, ensure you have installed:

1. **Node.js** (v14 or higher)
   - Download from: https://nodejs.org/
   - Verify installation:
     ```bash
     node --version
     npm --version
     ```

2. **JSON Server** (will be installed globally)

3. **Modern Web Browser** (Chrome, Firefox, Edge, Safari)

---

## 🛠️ Installation & Setup

### Step 1: Install JSON Server

Open your terminal/command prompt and run:

```bash
npm install -g json-server
```

**Verify installation:**
```bash
json-server --version
```

### Step 2: Create Project Directory

```bash
# Create a new directory for the project
mkdir employee-management
cd employee-management
```

### Step 3: Add Database File

1. Create a file named `db.json` in your project directory
2. Copy the contents from the provided `db.json` file
3. Save the file

**db.json structure includes:**
- `employees` - 10 sample employees with complete details
- `teams` - 5 teams across different departments
- `departments` - 5 departments with budgets
- `attendance` - Sample attendance records
- `leaves` - Leave requests
- `projects` - Active projects

### Step 4: Add HTML Application

1. Create a file named `index.html` in your project directory
2. Copy the contents from `advanced-crud-app.html`
3. Save the file

**Your project structure should look like:**
```
employee-management/
├── db.json
└── index.html
```

---

## 🚀 Running the Application

### Step 1: Start JSON Server

In your project directory, run:

```bash
json-server --watch db.json --port 5000
```

**Expected output:**
```
\{^_^}/ hi!

Loading db.json
Done

Resources
http://localhost:5000/employees
http://localhost:5000/teams
http://localhost:5000/departments
http://localhost:5000/attendance
http://localhost:5000/leaves
http://localhost:5000/projects

Home
http://localhost:5000

Type s + enter at any time to create a snapshot of the database
Watching...
```

✅ **JSON Server is now running on http://localhost:5000**

### Step 2: Open the Application

**Option 1: Direct File Open**
- Double-click `index.html` to open in your default browser

**Option 2: Using Live Server (Recommended)**
If you use VS Code:
1. Install "Live Server" extension
2. Right-click on `index.html`
3. Select "Open with Live Server"

**Option 3: Simple HTTP Server**
```bash
# Python 3
python -m http.server 8000

# Node.js (if http-server is installed)
npx http-server
```

Then navigate to: `http://localhost:8000/index.html`

### Step 3: Verify Connection

Look at the top-right corner of the application:
- 🟢 **Green "API Connected"** = Everything is working!
- 🔴 **Red "API Offline"** = JSON Server is not running

---

## 📡 API Endpoints

JSON Server provides the following REST API endpoints:

### Employees Endpoint

| Method | URL | Description | Example |
|--------|-----|-------------|---------|
| GET | `/employees` | Get all employees | `http://localhost:5000/employees` |
| GET | `/employees/:id` | Get single employee | `http://localhost:5000/employees/1` |
| POST | `/employees` | Create new employee | Body: `{employee_data}` |
| PUT | `/employees/:id` | Update employee | Body: `{updated_data}` |
| PATCH | `/employees/:id` | Partial update | Body: `{field: value}` |
| DELETE | `/employees/:id` | Delete employee | `http://localhost:5000/employees/1` |

### Query Parameters

**Filtering:**
```
GET /employees?department=Engineering
GET /employees?status=Active
GET /employees?salary_gte=80000
```

**Sorting:**
```
GET /employees?_sort=salary&_order=desc
GET /employees?_sort=firstName,lastName
```

**Pagination:**
```
GET /employees?_page=1&_limit=10
```

**Full-text Search:**
```
GET /employees?q=john
```

**Relationships:**
```
GET /employees?_embed=team
GET /employees/1?_expand=team
```

### Other Endpoints

- `GET /teams` - Get all teams
- `GET /departments` - Get all departments
- `GET /attendance` - Get attendance records
- `GET /leaves` - Get leave requests
- `GET /projects` - Get projects

---

## 🎨 Application Features

### 1. Dashboard Statistics
- Total Employees Count
- Active Employees Count
- Total Departments
- Total Teams
- Average Salary

### 2. Employee List Features

**Search:**
- Real-time search across name, email, department, position, skills
- Instant filtering as you type

**Filters:**
- Filter by Department (dropdown)
- Filter by Status (Active/Inactive/On Leave)

**Sorting:**
- Click any column header to sort
- Toggle between ascending/descending order
- Visual sort indicators

**Batch Operations:**
- Select multiple employees using checkboxes
- "Select All" functionality
- Batch delete selected employees
- Selection counter display

**Actions per Employee:**
- 👁️ View - See detailed information
- ✏️ Edit - Modify employee details
- 🗑️ Delete - Remove employee

### 3. Employee Form (Create/Edit)

**Comprehensive sections:**

1. **Basic Information**
   - First Name*, Last Name*
   - Email*, Phone

2. **Job Information**
   - Department*, Position
   - Salary, Experience (years)
   - Join Date, Status

3. **Skills**
   - Add multiple skills
   - Remove skills individually
   - Tag-based display

4. **Additional Information**
   - Education
   - Team Assignment
   - Manager Assignment

5. **Address**
   - Street, City, State, ZIP

6. **Emergency Contact**
   - Contact Name
   - Relationship
   - Contact Phone

### 4. Teams Tab
- View all teams
- Team descriptions
- Department associations
- Member counts
- Team leaders

### 5. Departments Tab
- Department overview cards
- Budget information
- Head count
- Location details
- Department codes

### 6. Analytics Tab

**Interactive Charts:**
1. **Employees by Department** (Doughnut Chart)
2. **Salary Distribution** (Bar Chart)
3. **Experience Levels** (Pie Chart)
4. **Employee Status** (Horizontal Bar Chart)

All charts are interactive and responsive!

### 7. Export Functionality
- Export filtered results to CSV
- Download with timestamp
- Includes all major fields

---

## 💻 Tech Stack

### Frontend
- **HTML5** - Structure
- **CSS3** - Styling with modern features
- **JavaScript (Vanilla ES6+)** - Application logic
- **Ant Design 5** - UI Component styling
- **Font Awesome 6** - Icons
- **Chart.js 4** - Data visualization

### Backend
- **JSON Server** - Full fake REST API
- **Node.js** - Runtime environment

### Features Used
- Fetch API for HTTP requests
- Async/Await for asynchronous operations
- ES6+ JavaScript features
- CSS Grid & Flexbox for layouts
- CSS Animations & Transitions
- Responsive Design

---

## 🔧 Troubleshooting

### Issue: "API Offline" Error

**Solutions:**
1. Make sure JSON Server is running:
   ```bash
   json-server --watch db.json --port 5000
   ```

2. Check if port 5000 is available:
   ```bash
   # Windows
   netstat -ano | findstr :5000
   
   # Mac/Linux
   lsof -i :5000
   ```

3. Try a different port:
   ```bash
   json-server --watch db.json --port 3001
   ```
   Then update API_URL in index.html:
   ```javascript
   const API_URL = 'http://localhost:3001';
   ```

### Issue: CORS Errors

**Solution:**
JSON Server automatically handles CORS. If you still see errors:

```bash
json-server --watch db.json --port 5000 --host 0.0.0.0
```

### Issue: Changes Not Persisting

**Check:**
1. Make sure `db.json` is not read-only
2. Verify JSON Server has write permissions
3. Check console for any errors

**Reset Database:**
```bash
# Stop JSON Server (Ctrl+C)
# Restore original db.json
# Restart JSON Server
json-server --watch db.json --port 5000
```

### Issue: Page Not Loading Properly

**Solutions:**
1. Clear browser cache (Ctrl+Shift+Delete)
2. Try incognito/private mode
3. Check browser console (F12) for errors
4. Ensure all CDN resources are loading:
   - Ant Design CSS
   - Font Awesome
   - Chart.js

### Issue: Charts Not Displaying

**Solution:**
1. Make sure Chart.js is loaded
2. Check browser console for errors
3. Click on "Analytics" tab to trigger chart rendering
4. Try refreshing the page

---

## 📝 Testing the Application

### 1. CREATE Operation
1. Click "Add Employee" button
2. Fill in required fields (marked with *)
3. Add some skills
4. Click "Save Employee"
5. ✅ Check: Employee appears in table
6. ✅ Check: db.json file updated

### 2. READ Operation
1. Observe employee list loads automatically
2. Try searching for an employee
3. Use department filter
4. Sort by different columns
5. ✅ Check: Data displays correctly

### 3. UPDATE Operation
1. Click "Edit" (✏️) button on any employee
2. Modify some fields
3. Click "Update Employee"
4. ✅ Check: Changes reflect in table
5. ✅ Check: db.json file updated

### 4. DELETE Operation
1. Click "Delete" (🗑️) button
2. Confirm deletion
3. ✅ Check: Employee removed from table
4. ✅ Check: db.json file updated

### 5. Batch Operations
1. Select multiple employees using checkboxes
2. Click "Delete Selected"
3. Confirm
4. ✅ Check: All selected employees deleted

### 6. Export Feature
1. Apply some filters
2. Click "Export CSV"
3. ✅ Check: CSV file downloads
4. ✅ Check: File contains filtered data

---

## 🎯 API Testing with Browser DevTools

1. Open Developer Tools (F12)
2. Go to "Network" tab
3. Filter by "Fetch/XHR"
4. Perform any CRUD operation
5. Inspect the request/response:
   - Request Method (GET/POST/PUT/DELETE)
   - Request URL
   - Request Payload
   - Response Status (200, 201, 204)
   - Response Data

---

## 📊 Sample Data Overview

**10 Pre-loaded Employees:**
- Engineering Department: 3 employees
- Marketing Department: 2 employees
- Sales Department: 2 employees
- HR Department: 1 employee
- Finance Department: 2 employees

**Departments:**
- Engineering ($2.5M budget)
- Marketing ($800K budget)
- Sales ($1.5M budget)
- HR ($500K budget)
- Finance ($1.2M budget)

**Teams:**
- 5 teams across different departments
- Each with designated leaders
- Member counts tracked

---

## 🚀 Next Steps & Enhancements

Consider adding:
1. **Authentication** - Login/logout functionality
2. **User Roles** - Admin, Manager, Employee permissions
3. **File Upload** - Profile pictures, documents
4. **Real Database** - Replace JSON Server with MongoDB/PostgreSQL
5. **Backend API** - Node.js/Express, Python/Django, etc.
6. **Advanced Analytics** - More charts and insights
7. **Notifications** - Email alerts for actions
8. **Mobile App** - React Native version
9. **Real-time Updates** - WebSocket integration
10. **PDF Reports** - Generate employee reports

---

## 📚 Resources

- [JSON Server Documentation](https://github.com/typicode/json-server)
- [Ant Design](https://ant.design/)
- [Chart.js Documentation](https://www.chartjs.org/docs/)
- [Font Awesome Icons](https://fontawesome.com/icons)
- [Fetch API MDN](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API)

---

## 🎉 Congratulations!

You now have a fully functional Employee Management System with:
- ✅ Real REST API backend
- ✅ Beautiful Ant Design UI
- ✅ Complete CRUD operations
- ✅ Advanced features (search, filter, sort, export)
- ✅ Analytics dashboard
- ✅ Batch operations
- ✅ Complex data relationships

**Happy Coding! 🚀**

---

## 💡 Tips

1. **Keep JSON Server Running** - Don't close the terminal window
2. **Save Often** - Changes are saved automatically to db.json
3. **Backup db.json** - Keep a copy of original data
4. **Monitor Console** - Check for any errors in browser console
5. **Test API** - Use Postman or browser to test endpoints directly

---

## 📞 Support

If you encounter any issues:
1. Check the Troubleshooting section
2. Verify JSON Server is running
3. Check browser console for errors
4. Review API endpoints documentation
5. Ensure all files are in correct locations

---

**Created with ❤️ using Vanilla JavaScript, Ant Design, and JSON Server**

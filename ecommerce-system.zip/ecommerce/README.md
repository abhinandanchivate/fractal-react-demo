# 🛒 Advanced E-Commerce Management System with JSON Server

## Complete CRUD Application with Ant Design & Vanilla JavaScript

---

## 📋 Table of Contents
1. [Overview](#overview)
2. [Features](#features)
3. [Prerequisites](#prerequisites)
4. [Installation & Setup](#installation--setup)
5. [Running the Application](#running-the-application)
6. [API Endpoints](#api-endpoints)
7. [Application Features](#application-features)
8. [Tech Stack](#tech-stack)
9. [Troubleshooting](#troubleshooting)

---

## 🎯 Overview

This is a comprehensive E-Commerce Management System featuring:
- **Full CRUD Operations** (Create, Read, Update, Delete) for 5 entities
- **Real JSON Server Backend** for REST API
- **Beautiful Modern UI** with Ant Design styling
- **Advanced Features**: Search, Filter, Sort, Pagination
- **Analytics Dashboard** with interactive charts
- **Multi-entity Management**: Products, Customers, Orders, Categories, Reviews
- **Complex Data Relationships** between entities

---

## ✨ Features

### Product Management
- ✅ Create, view, edit, and delete products
- ✅ Product details: name, SKU, price, stock, category
- ✅ Product images and ratings
- ✅ Stock level indicators
- ✅ Category filtering
- ✅ Search across all product fields
- ✅ Brand and tag management

### Customer Management
- ✅ Full customer profiles with contact information
- ✅ Membership tiers (Platinum, Gold, Silver, Bronze)
- ✅ Customer spending analytics
- ✅ Order history tracking
- ✅ Shipping and billing addresses
- ✅ Customer status management
- ✅ Filter by tier and status

### Order Management
- ✅ Create and track orders
- ✅ Order status workflow (Pending → Processing → Shipped → Delivered)
- ✅ Order items and totals
- ✅ Payment method tracking
- ✅ Shipping information
- ✅ Order history
- ✅ Status-based filtering

### Category Management
- ✅ Organize products by categories
- ✅ Category descriptions and images
- ✅ Product count per category
- ✅ Featured categories
- ✅ SEO-friendly slugs
- ✅ Category status management

### Review Management
- ✅ Customer product reviews
- ✅ Star ratings (1-5)
- ✅ Review approval workflow
- ✅ Helpful/Not helpful tracking
- ✅ Verified purchase badges
- ✅ Filter by rating and status

### Analytics Dashboard
- 📊 **Real-time Statistics** - Revenue, products, customers, orders
- 📈 **Sales Charts** - Daily sales trends
- 🎨 **Category Distribution** - Products by category
- 📉 **Performance Metrics** - Growth indicators

---

## 📦 Prerequisites

Before you begin, ensure you have installed:

1. **Node.js** (v14 or higher)
   - Download from: https://nodejs.org/
   - Verify installation:
     ```bash
     node --version
     npm --version
     ```

2. **JSON Server** (will be installed globally)

3. **Modern Web Browser** (Chrome, Firefox, Edge, Safari)

---

## 🛠️ Installation & Setup

### Step 1: Install JSON Server

Open your terminal/command prompt and run:

```bash
npm install -g json-server
```

**Verify installation:**
```bash
json-server --version
```

### Step 2: Create Project Directory

```bash
mkdir ecommerce-system
cd ecommerce-system
```

### Step 3: Extract Project Files

Extract all project files to the `ecommerce-system` directory:
- `db.json` - Database with sample data
- `advanced-ecommerce-app.html` - Main application
- `package.json` - Project configuration
- `README.md` - This file

---

## 🚀 Running the Application

### Method 1: Using npm scripts (Recommended)

```bash
npm start
```

### Method 2: Direct command

```bash
json-server --watch db.json --port 3000
```

### Step 2: Open the Application

1. After starting JSON Server, you should see:
   ```
   \{^_^}/ hi!

   Loading db.json
   Done

   Resources
   http://localhost:3000/products
   http://localhost:3000/customers
   http://localhost:3000/orders
   http://localhost:3000/categories
   http://localhost:3000/reviews

   Home
   http://localhost:3000
   ```

2. Open `advanced-ecommerce-app.html` in your web browser
   - **Windows**: Double-click the file or drag to browser
   - **Mac**: Double-click the file
   - **Alternative**: Right-click → Open with → Your Browser

3. The application should now be running! 🎉

---

## 🔌 API Endpoints

JSON Server automatically creates a full REST API:

### Products
- `GET /products` - Get all products
- `GET /products/:id` - Get product by ID
- `POST /products` - Create new product
- `PUT /products/:id` - Update product (full)
- `PATCH /products/:id` - Update product (partial)
- `DELETE /products/:id` - Delete product

### Customers
- `GET /customers` - Get all customers
- `GET /customers/:id` - Get customer by ID
- `POST /customers` - Create new customer
- `PATCH /customers/:id` - Update customer
- `DELETE /customers/:id` - Delete customer

### Orders
- `GET /orders` - Get all orders
- `GET /orders/:id` - Get order by ID
- `POST /orders` - Create new order
- `PATCH /orders/:id` - Update order
- `DELETE /orders/:id` - Delete order

### Categories
- `GET /categories` - Get all categories
- `GET /categories/:id` - Get category by ID
- `POST /categories` - Create new category
- `PATCH /categories/:id` - Update category
- `DELETE /categories/:id` - Delete category

### Reviews
- `GET /reviews` - Get all reviews
- `GET /reviews/:id` - Get review by ID
- `POST /reviews` - Create new review
- `PATCH /reviews/:id` - Update review
- `DELETE /reviews/:id` - Delete review

### Query Parameters
- `_sort` - Sort by field (e.g., `?_sort=price`)
- `_order` - Sort order (asc/desc)
- `_limit` - Limit results
- `_page` - Paginate results
- `q` - Full-text search

**Example:**
```
http://localhost:3000/products?_sort=price&_order=desc&_limit=10
```

---

## 🎨 Application Features

### Dashboard
- Overview of all key metrics
- Sales trend visualization
- Category distribution chart
- Quick access to recent activity

### Products Tab
- **Search**: Search by name, SKU, or brand
- **Filter**: By category and status
- **Sort**: By price, stock, or rating
- **Actions**: Add, Edit, Delete products
- **Pagination**: Navigate through large datasets
- **Stock Indicators**: Visual stock level displays

### Customers Tab
- **Search**: Search by name, email, or phone
- **Filter**: By membership tier and status
- **Customer Cards**: Avatar, contact info, spending
- **Actions**: Add, Edit, Delete customers
- **Tier Badges**: Visual membership level indicators

### Orders Tab
- **Search**: Search by order number or tracking
- **Filter**: By order status
- **Order Details**: Items, totals, shipping
- **Actions**: View, Edit, Delete orders
- **Status Badges**: Visual order status

### Categories Tab
- **Search**: Search by name or slug
- **Category Cards**: Image, description, product count
- **Actions**: Add, Edit, Delete categories
- **Featured Tags**: Highlight important categories

### Reviews Tab
- **Search**: Search reviews by content
- **Filter**: By rating (1-5 stars) and status
- **Review Details**: Title, comment, date
- **Actions**: Delete reviews
- **Rating Display**: Visual star ratings

---

## 🛠️ Tech Stack

### Frontend
- **HTML5** - Structure
- **CSS3** - Styling with modern features
- **Vanilla JavaScript** - No framework dependencies
- **Ant Design** - UI component library (CSS only)
- **Font Awesome** - Icons
- **Chart.js** - Data visualization

### Backend
- **JSON Server** - Full fake REST API
- **Node.js** - Runtime environment

### Features
- **RESTful API** - Standard HTTP methods
- **CRUD Operations** - Complete data management
- **Responsive Design** - Works on all devices
- **Client-side Routing** - Tab-based navigation
- **Real-time Updates** - Instant UI refresh

---

## 🐛 Troubleshooting

### Issue: JSON Server not found
**Solution:**
```bash
npm install -g json-server
```

### Issue: Port 3000 already in use
**Solution:**
```bash
# Use a different port
json-server --watch db.json --port 3001

# Then update API_BASE in HTML file:
const API_BASE = 'http://localhost:3001';
```

### Issue: CORS errors
**Solution:**
JSON Server has CORS enabled by default. If issues persist, start with:
```bash
json-server --watch db.json --port 3000 --middlewares ./cors-middleware.js
```

### Issue: Changes not saving
**Solution:**
1. Ensure JSON Server is running
2. Check browser console for errors
3. Verify `db.json` file permissions
4. Try restarting JSON Server

### Issue: Cannot load data
**Solution:**
1. Verify JSON Server is running on port 3000
2. Check `db.json` exists and is valid JSON
3. Open browser console and check for errors
4. Try accessing http://localhost:3000/products directly

---

## 📝 Tips & Best Practices

1. **Keep JSON Server Running**: Don't close the terminal while using the app

2. **Backup Data**: Make copies of `db.json` before testing

3. **Browser DevTools**: Use F12 to debug issues

4. **API Testing**: Use Postman or curl to test endpoints

5. **Data Persistence**: All changes are saved to `db.json`

---

## 🎓 Learning Resources

- [JSON Server Documentation](https://github.com/typicode/json-server)
- [MDN Web Docs](https://developer.mozilla.org/)
- [Chart.js Documentation](https://www.chartjs.org/docs/)
- [Ant Design Guidelines](https://ant.design/)

---

## 📄 License

MIT License - Feel free to use this project for learning and development!

---

## 🤝 Contributing

This is an educational project. Feel free to:
- Fork and modify
- Report issues
- Suggest improvements
- Add new features

---

## 🌟 Features to Add (Ideas)

- [ ] Export data to CSV/Excel
- [ ] Print reports
- [ ] Email notifications
- [ ] Image upload
- [ ] Inventory alerts
- [ ] Advanced analytics
- [ ] Multi-language support
- [ ] Dark mode
- [ ] User authentication

---

**Happy Coding! 🚀**

For questions or issues, refer to the QUICKSTART.md and API-TESTING.md files.

# ⚡ Quick Start Guide - E-Commerce Management System

Get up and running in under 5 minutes!

---

## 🎯 Super Quick Setup (3 Steps)

### Step 1: Install JSON Server (One-time setup)
```bash
npm install -g json-server
```

### Step 2: Start the Server
```bash
cd /path/to/ecommerce-system
json-server --watch db.json --port 3000
```

Or simply:
```bash
npm start
```

### Step 3: Open the App
Double-click `advanced-ecommerce-app.html` in your browser

**That's it! You're ready to go! 🎉**

---

## 📱 Using the Application

### Dashboard
1. Click **Dashboard** tab to see analytics
2. View real-time statistics
3. Check sales charts and trends

### Managing Products
1. Click **Products** tab
2. Click **Add Product** button
3. Fill in the form:
   - Product Name
   - SKU (unique identifier)
   - Price & Stock
   - Category
   - Description
4. Click **Save Product**

**Edit/Delete:**
- Click the ✏️ icon to edit
- Click the 🗑️ icon to delete

### Managing Customers
1. Click **Customers** tab
2. Click **Add Customer** button
3. Fill in customer details
4. Select membership tier
5. Click **Save Customer**

### Creating Orders
1. Click **Orders** tab
2. Click **Create Order** button
3. Fill in order details:
   - Order Number
   - Select Customer
   - Enter amounts
   - Set status
4. Click **Save Order**

### Managing Categories
1. Click **Categories** tab
2. Click **Add Category** button
3. Enter category information
4. Click **Save Category**

### Viewing Reviews
1. Click **Reviews** tab
2. Browse customer reviews
3. Filter by rating or status
4. Delete spam or inappropriate reviews

---

## 🔍 Search & Filter

### Search Box
- Type in the search box
- Results update automatically
- Searches across multiple fields

### Filters
- **Products**: Filter by category and status
- **Customers**: Filter by membership tier and status
- **Orders**: Filter by order status
- **Reviews**: Filter by rating and status

### Sorting
- Click on column headers with ▲▼ icons
- Toggle between ascending/descending

---

## 💡 Quick Tips

1. **Auto-save**: Changes save immediately to `db.json`

2. **Sample Data**: The app comes with 10 products, 10 customers, 10 orders, 5 categories, and 15 reviews

3. **Keyboard Shortcuts**:
   - `Ctrl + F`: Focus search box (in most browsers)
   - `Esc`: Close modals

4. **Pagination**: Use arrows to navigate pages (10 items per page)

5. **Real-time**: All changes reflect immediately across tabs

---

## 🚨 Common Issues & Quick Fixes

### "Cannot connect to API"
**Fix:** Make sure JSON Server is running
```bash
json-server --watch db.json --port 3000
```

### "Port 3000 in use"
**Fix:** Use a different port
```bash
json-server --watch db.json --port 3001
```
Then update the HTML file:
```javascript
const API_BASE = 'http://localhost:3001';
```

### "Changes not saving"
**Fix:** 
1. Check if JSON Server is running
2. Refresh the browser (F5)
3. Check browser console (F12) for errors

---

## 📊 Understanding the Data

### Products
- **SKU**: Stock Keeping Unit (unique product code)
- **Stock**: Number of items available
- **Category**: Product classification
- **Rating**: Average customer rating (1-5 stars)

### Customers
- **Tier**: Bronze → Silver → Gold → Platinum
- **Total Spent**: Lifetime purchase value
- **Total Orders**: Number of purchases made

### Orders
- **Status Flow**: Pending → Processing → Shipped → Delivered
- **Payment Status**: Paid, Pending, Refunded
- **Items**: Products included in the order

### Categories
- **Slug**: URL-friendly identifier
- **Featured**: Highlighted on main pages
- **Product Count**: Number of products in category

### Reviews
- **Verified**: Confirmed purchase
- **Helpful**: User feedback on review quality
- **Status**: Approved, Pending, Rejected

---

## 🎨 Customization Quick Guide

### Change Colors
Edit the `:root` variables in the HTML file:
```css
:root {
    --primary-color: #1890ff;  /* Blue */
    --success-color: #52c41a;  /* Green */
    --warning-color: #faad14;  /* Orange */
    --error-color: #ff4d4f;    /* Red */
}
```

### Change Port
In the HTML file, find and modify:
```javascript
const API_BASE = 'http://localhost:3000';
```

### Change Items Per Page
In the HTML file, modify:
```javascript
itemsPerPage: 10  // Change to 20, 50, etc.
```

---

## 📝 Sample API Calls

### Get All Products
```bash
curl http://localhost:3000/products
```

### Get Product by ID
```bash
curl http://localhost:3000/products/1
```

### Create New Product
```bash
curl -X POST http://localhost:3000/products \
  -H "Content-Type: application/json" \
  -d '{"name":"New Product","price":99.99,"stock":50}'
```

### Update Product
```bash
curl -X PATCH http://localhost:3000/products/1 \
  -H "Content-Type: application/json" \
  -d '{"price":79.99}'
```

### Delete Product
```bash
curl -X DELETE http://localhost:3000/products/1
```

---

## 🎓 Next Steps

1. **Explore the Data**: Browse through all tabs
2. **Add Your Data**: Create your own products and customers
3. **Test Features**: Try search, filter, and sort
4. **Check Dashboard**: View your analytics
5. **Read API-TESTING.md**: Learn advanced API usage

---

## 🆘 Need Help?

1. Check **README.md** for detailed documentation
2. See **API-TESTING.md** for API examples
3. Read **FILE-OVERVIEW.md** for code structure
4. Open browser console (F12) for error messages

---

## ✅ Checklist

Before starting, make sure you have:
- [ ] Node.js installed
- [ ] JSON Server installed (`npm install -g json-server`)
- [ ] All project files in one folder
- [ ] JSON Server running (`json-server --watch db.json`)
- [ ] HTML file opened in browser

---

**You're all set! Start managing your e-commerce data! 🚀**

For more advanced features, check out the full README.md file.

# 🧪 API Testing Guide - E-Commerce Management System

Complete guide to testing the JSON Server REST API

---

## 📋 Table of Contents
1. [Base URL](#base-url)
2. [Products API](#products-api)
3. [Customers API](#customers-api)
4. [Orders API](#orders-api)
5. [Categories API](#categories-api)
6. [Reviews API](#reviews-api)
7. [Advanced Queries](#advanced-queries)
8. [Testing Tools](#testing-tools)

---

## 🌐 Base URL

All API endpoints are prefixed with:
```
http://localhost:3000
```

Default port is 3000. If you changed it, update accordingly.

---

## 📦 Products API

### Get All Products
```bash
curl http://localhost:3000/products
```

**Response:**
```json
[
  {
    "id": 1,
    "name": "Wireless Bluetooth Headphones",
    "sku": "WBH-001",
    "price": 129.99,
    "stock": 145,
    "categoryId": 1,
    "brand": "AudioTech Pro",
    "rating": 4.5,
    "status": "Active"
  }
]
```

### Get Product by ID
```bash
curl http://localhost:3000/products/1
```

### Get Products by Category
```bash
curl http://localhost:3000/products?categoryId=1
```

### Search Products
```bash
curl http://localhost:3000/products?q=headphone
```

### Filter Active Products
```bash
curl http://localhost:3000/products?status=Active
```

### Sort Products by Price
```bash
# Ascending
curl http://localhost:3000/products?_sort=price&_order=asc

# Descending
curl http://localhost:3000/products?_sort=price&_order=desc
```

### Get Low Stock Products
```bash
curl "http://localhost:3000/products?stock_lte=50"
```

### Create New Product
```bash
curl -X POST http://localhost:3000/products \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Smart Watch Pro",
    "sku": "SWP-001",
    "description": "Advanced fitness tracking smartwatch",
    "price": 299.99,
    "costPrice": 150.00,
    "categoryId": 1,
    "stock": 75,
    "lowStockThreshold": 20,
    "brand": "TechFit",
    "rating": 0,
    "reviewCount": 0,
    "tags": ["Electronics", "Wearable", "Fitness"],
    "status": "Active",
    "featured": true,
    "images": [
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400"
    ],
    "createdAt": "2024-10-29"
  }'
```

### Update Product (Full Replace)
```bash
curl -X PUT http://localhost:3000/products/1 \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Updated Product Name",
    "sku": "WBH-001",
    "price": 139.99,
    "stock": 150,
    "categoryId": 1,
    "status": "Active"
  }'
```

### Update Product (Partial)
```bash
curl -X PATCH http://localhost:3000/products/1 \
  -H "Content-Type: application/json" \
  -d '{
    "price": 119.99,
    "stock": 160
  }'
```

### Delete Product
```bash
curl -X DELETE http://localhost:3000/products/1
```

---

## 👥 Customers API

### Get All Customers
```bash
curl http://localhost:3000/customers
```

### Get Customer by ID
```bash
curl http://localhost:3000/customers/1
```

### Get Customers by Tier
```bash
curl http://localhost:3000/customers?membershipTier=Gold
```

### Get Active Customers
```bash
curl http://localhost:3000/customers?status=Active
```

### Search Customers
```bash
curl http://localhost:3000/customers?q=john
```

### Get VIP Customers (High Spenders)
```bash
curl "http://localhost:3000/customers?totalSpent_gte=5000"
```

### Sort by Total Spent
```bash
curl "http://localhost:3000/customers?_sort=totalSpent&_order=desc"
```

### Create New Customer
```bash
curl -X POST http://localhost:3000/customers \
  -H "Content-Type: application/json" \
  -d '{
    "firstName": "Alice",
    "lastName": "Cooper",
    "email": "alice.cooper@email.com",
    "phone": "+1-555-0200",
    "dateOfBirth": "1990-05-15",
    "gender": "Female",
    "status": "Active",
    "membershipTier": "Bronze",
    "joinDate": "2024-10-29",
    "totalOrders": 0,
    "totalSpent": 0,
    "shippingAddress": {
      "street": "123 New Street",
      "city": "Boston",
      "state": "MA",
      "zipCode": "02101",
      "country": "USA"
    },
    "billingAddress": {
      "street": "123 New Street",
      "city": "Boston",
      "state": "MA",
      "zipCode": "02101",
      "country": "USA"
    },
    "preferences": {
      "newsletter": true,
      "smsNotifications": false,
      "emailNotifications": true
    },
    "tags": ["New Customer"],
    "avatar": "https://i.pravatar.cc/150?img=25"
  }'
```

### Update Customer Tier
```bash
curl -X PATCH http://localhost:3000/customers/1 \
  -H "Content-Type: application/json" \
  -d '{
    "membershipTier": "Platinum"
  }'
```

### Update Customer Status
```bash
curl -X PATCH http://localhost:3000/customers/1 \
  -H "Content-Type: application/json" \
  -d '{
    "status": "Inactive"
  }'
```

### Delete Customer
```bash
curl -X DELETE http://localhost:3000/customers/1
```

---

## 🛒 Orders API

### Get All Orders
```bash
curl http://localhost:3000/orders
```

### Get Order by ID
```bash
curl http://localhost:3000/orders/1
```

### Get Orders by Status
```bash
curl http://localhost:3000/orders?status=Pending
```

### Get Orders by Customer
```bash
curl http://localhost:3000/orders?customerId=1
```

### Get Recent Orders (Last 7 days)
```bash
curl "http://localhost:3000/orders?orderDate_gte=2024-10-20"
```

### Get High Value Orders
```bash
curl "http://localhost:3000/orders?total_gte=200"
```

### Sort by Date
```bash
curl "http://localhost:3000/orders?_sort=orderDate&_order=desc"
```

### Create New Order
```bash
curl -X POST http://localhost:3000/orders \
  -H "Content-Type: application/json" \
  -d '{
    "orderNumber": "ORD-2024-100",
    "customerId": 1,
    "orderDate": "2024-10-29",
    "status": "Pending",
    "paymentMethod": "Credit Card",
    "paymentStatus": "Paid",
    "subtotal": 129.99,
    "tax": 10.40,
    "shipping": 10.00,
    "discount": 0,
    "total": 150.39,
    "items": [
      {
        "productId": 1,
        "productName": "Wireless Bluetooth Headphones",
        "quantity": 1,
        "price": 129.99,
        "total": 129.99
      }
    ],
    "shippingAddress": {
      "street": "123 Main Street",
      "city": "New York",
      "state": "NY",
      "zipCode": "10001",
      "country": "USA"
    },
    "trackingNumber": null,
    "shippingMethod": "Standard",
    "estimatedDelivery": "2024-11-05",
    "actualDelivery": null,
    "notes": ""
  }'
```

### Update Order Status
```bash
curl -X PATCH http://localhost:3000/orders/1 \
  -H "Content-Type: application/json" \
  -d '{
    "status": "Shipped",
    "trackingNumber": "TRK9999888777"
  }'
```

### Mark Order as Delivered
```bash
curl -X PATCH http://localhost:3000/orders/1 \
  -H "Content-Type: application/json" \
  -d '{
    "status": "Delivered",
    "actualDelivery": "2024-10-30"
  }'
```

### Cancel Order
```bash
curl -X PATCH http://localhost:3000/orders/1 \
  -H "Content-Type: application/json" \
  -d '{
    "status": "Cancelled",
    "paymentStatus": "Refunded"
  }'
```

### Delete Order
```bash
curl -X DELETE http://localhost:3000/orders/1
```

---

## 🏷️ Categories API

### Get All Categories
```bash
curl http://localhost:3000/categories
```

### Get Category by ID
```bash
curl http://localhost:3000/categories/1
```

### Get Featured Categories
```bash
curl http://localhost:3000/categories?featured=true
```

### Get Active Categories
```bash
curl http://localhost:3000/categories?status=Active
```

### Search Categories
```bash
curl http://localhost:3000/categories?q=electronics
```

### Sort by Product Count
```bash
curl "http://localhost:3000/categories?_sort=productCount&_order=desc"
```

### Create New Category
```bash
curl -X POST http://localhost:3000/categories \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Toys & Games",
    "slug": "toys-games",
    "description": "Fun toys and games for all ages",
    "image": "https://images.unsplash.com/photo-1558060370-d644479cb6f7?w=400",
    "parentId": null,
    "level": 0,
    "productCount": 0,
    "status": "Active",
    "featured": false,
    "displayOrder": 6,
    "seoTitle": "Toys & Games - Fun for Everyone",
    "seoDescription": "Browse our collection of toys and games",
    "seoKeywords": "toys, games, children, fun, play"
  }'
```

### Update Category
```bash
curl -X PATCH http://localhost:3000/categories/1 \
  -H "Content-Type: application/json" \
  -d '{
    "featured": true,
    "productCount": 15
  }'
```

### Delete Category
```bash
curl -X DELETE http://localhost:3000/categories/1
```

---

## ⭐ Reviews API

### Get All Reviews
```bash
curl http://localhost:3000/reviews
```

### Get Review by ID
```bash
curl http://localhost:3000/reviews/1
```

### Get Reviews for Product
```bash
curl http://localhost:3000/reviews?productId=1
```

### Get Reviews by Customer
```bash
curl http://localhost:3000/reviews?customerId=1
```

### Get 5-Star Reviews
```bash
curl http://localhost:3000/reviews?rating=5
```

### Get Approved Reviews
```bash
curl http://localhost:3000/reviews?status=Approved
```

### Get Verified Reviews
```bash
curl http://localhost:3000/reviews?verified=true
```

### Sort by Helpful Count
```bash
curl "http://localhost:3000/reviews?_sort=helpful&_order=desc"
```

### Create New Review
```bash
curl -X POST http://localhost:3000/reviews \
  -H "Content-Type: application/json" \
  -d '{
    "productId": 1,
    "customerId": 1,
    "rating": 5,
    "title": "Excellent product!",
    "comment": "Very satisfied with this purchase. Highly recommend!",
    "verified": true,
    "helpful": 0,
    "notHelpful": 0,
    "status": "Pending",
    "reviewDate": "2024-10-29",
    "images": []
  }'
```

### Approve Review
```bash
curl -X PATCH http://localhost:3000/reviews/1 \
  -H "Content-Type: application/json" \
  -d '{
    "status": "Approved"
  }'
```

### Mark Review as Helpful
```bash
curl -X PATCH http://localhost:3000/reviews/1 \
  -H "Content-Type: application/json" \
  -d '{
    "helpful": 46
  }'
```

### Delete Review
```bash
curl -X DELETE http://localhost:3000/reviews/1
```

---

## 🔍 Advanced Queries

### Pagination
```bash
# Get page 2, 10 items per page
curl "http://localhost:3000/products?_page=2&_limit=10"
```

### Multiple Filters
```bash
# Active products in category 1 with price > 50
curl "http://localhost:3000/products?categoryId=1&status=Active&price_gte=50"
```

### Range Queries
```bash
# Products between $50 and $150
curl "http://localhost:3000/products?price_gte=50&price_lte=150"
```

### Full-Text Search
```bash
# Search across all fields
curl "http://localhost:3000/products?q=wireless"
```

### Sorting by Multiple Fields
```bash
# Sort by category, then price
curl "http://localhost:3000/products?_sort=categoryId,price&_order=asc,desc"
```

### Include Related Data (Expand)
```bash
# Get orders with customer info
curl "http://localhost:3000/orders?_embed=customer"
```

### Get Relationships
```bash
# Get all orders for a customer
curl "http://localhost:3000/customers/1/orders"

# Get all reviews for a product
curl "http://localhost:3000/products/1/reviews"
```

### Operators Available
- `_gte` - Greater than or equal
- `_lte` - Less than or equal
- `_ne` - Not equal
- `_like` - Contains (case-insensitive)

**Examples:**
```bash
# Price greater than or equal to 100
curl "http://localhost:3000/products?price_gte=100"

# Name contains "smart"
curl "http://localhost:3000/products?name_like=smart"

# Status not equal to "Inactive"
curl "http://localhost:3000/products?status_ne=Inactive"
```

---

## 🛠️ Testing Tools

### 1. cURL (Command Line)
Best for: Quick tests, scripts
```bash
curl -X GET http://localhost:3000/products
```

### 2. Postman
Best for: Complex requests, collections
1. Download from: https://www.postman.com/
2. Create new request
3. Set URL: `http://localhost:3000/products`
4. Choose method: GET, POST, etc.
5. Click Send

### 3. Insomnia
Best for: API design, GraphQL
1. Download from: https://insomnia.rest/
2. Similar to Postman
3. Great UI/UX

### 4. Browser
Best for: GET requests, debugging
```
http://localhost:3000/products
```

### 5. JavaScript Fetch
Best for: Frontend integration
```javascript
// GET request
fetch('http://localhost:3000/products')
  .then(res => res.json())
  .then(data => console.log(data));

// POST request
fetch('http://localhost:3000/products', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'New Product',
    price: 99.99
  })
})
  .then(res => res.json())
  .then(data => console.log(data));
```

---

## 📊 Response Codes

| Code | Meaning |
|------|---------|
| 200  | OK - Request successful |
| 201  | Created - Resource created |
| 404  | Not Found - Resource doesn't exist |
| 500  | Server Error - Something went wrong |

---

## 💡 Pro Tips

1. **Test in Order**: Test GET before POST, POST before DELETE

2. **Save IDs**: Note created resource IDs for further testing

3. **Use Variables**: In Postman/Insomnia, use variables for base URL

4. **Check db.json**: View the database file to see actual data

5. **Backup First**: Copy `db.json` before destructive tests

6. **Use Headers**: Always include `Content-Type: application/json` for POST/PATCH

7. **Watch Console**: Check browser/terminal for errors

---

## 🧪 Test Scenarios

### Scenario 1: Complete Product Lifecycle
```bash
# 1. Create product
curl -X POST http://localhost:3000/products -H "Content-Type: application/json" -d '{"name":"Test Product","price":99.99,"stock":10,"categoryId":1}'

# 2. Get product (use ID from step 1)
curl http://localhost:3000/products/11

# 3. Update price
curl -X PATCH http://localhost:3000/products/11 -H "Content-Type: application/json" -d '{"price":79.99}'

# 4. Get updated product
curl http://localhost:3000/products/11

# 5. Delete product
curl -X DELETE http://localhost:3000/products/11
```

### Scenario 2: Customer Orders
```bash
# 1. Get customer
curl http://localhost:3000/customers/1

# 2. Get customer's orders
curl http://localhost:3000/orders?customerId=1

# 3. Create new order for customer
curl -X POST http://localhost:3000/orders -H "Content-Type: application/json" -d '{"customerId":1,"orderNumber":"ORD-TEST","status":"Pending","total":199.99}'
```

### Scenario 3: Product Reviews
```bash
# 1. Get product
curl http://localhost:3000/products/1

# 2. Get product reviews
curl http://localhost:3000/reviews?productId=1

# 3. Add new review
curl -X POST http://localhost:3000/reviews -H "Content-Type: application/json" -d '{"productId":1,"customerId":1,"rating":5,"title":"Great!","comment":"Love it"}'
```

---

**Happy Testing! 🧪**

For more information, check the README.md file.
